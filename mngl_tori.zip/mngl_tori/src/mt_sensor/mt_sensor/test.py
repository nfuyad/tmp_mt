msg="(Hello)"

if msg[0]=="(":
    print("Done")